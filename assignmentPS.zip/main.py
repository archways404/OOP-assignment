from menu import MainMenu

if __name__ == "__main__":
    menu = MainMenu()
    menu.display()
